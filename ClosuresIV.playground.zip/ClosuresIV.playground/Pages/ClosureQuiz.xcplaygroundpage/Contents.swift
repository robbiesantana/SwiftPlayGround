import foundation

let average = { (_ nums: [Double]) -> Double in
    var sum = 0.0
    for num in nums {
        sum += num
    }
    return sum / Double(nums.count)
}
let averageOfNumbers = average([12.1, 2.2, 33.2])
print(averageOfNumbers.rounded())
