import PlaygroundSupport
import SwiftUI
import Combine
import Foundation
import CoreData

struct Pelicula {
    var nombre: String
    var genero: Genero
    var anno: Int
    let score: Double
}

enum Genero {
    case romance, accion, horror, thriller, comedia, drama, terror, cienciaFiccion, aventura
}


var carteleraNov2024: [Pelicula] = [
    Pelicula(nombre: "Annie Hall", genero: .romance, anno: 2022, score: 8.5),
    Pelicula(nombre: "Interstellar", genero: .cienciaFiccion, anno: 2014, score: 9.0),
    Pelicula(nombre: "Gladiator", genero: .accion, anno: 2000, score: 8.3),
    Pelicula(nombre: "Toy Story", genero: .comedia, anno: 1995, score: 8.2),
    Pelicula(nombre: "The Shining", genero: .terror, anno: 1980, score: 8.4),
    Pelicula(nombre: "The Notebook", genero: .romance, anno: 2004, score: 7.8),
    Pelicula(nombre: "Inception", genero: .cienciaFiccion, anno: 2010, score: 8.8),
    Pelicula(nombre: "Titanic", genero: .drama, anno: 1997, score: 8.1),
    Pelicula(nombre: "The Lion King", genero: .aventura, anno: 1994, score: 8.5),
    Pelicula(nombre: "Parasite", genero: .drama, anno: 2019, score: 9.1),
    Pelicula(nombre: "Mad Max Fury Road", genero: .accion, anno: 2015, score: 8.6)
]

var moviesNoventeras: (Pelicula) -> Bool = { pelicula in
    return pelicula.score > 8.3
}

var cartelera = carteleraNov2024.filter(moviesNoventeras)

print("Peliculas con puntuacion mayor a 8.3")
for movie in cartelera {
    print("🎬 \(movie.nombre)\r Score: \(movie.score)\n")
    
}

var moviesNombres: (Pelicula) -> String = { pelicula in
    return pelicula.nombre
}

let nombresP2 = carteleraNov2024.map(moviesNombres)

print("Nombres de las peliculas")
for nombre in nombresP2 {
    print("🎬 \(nombre)\n")
}
