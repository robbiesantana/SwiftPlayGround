import Cocoa

var greeting = "Hello, playground"

for char in "busy as a bumblebee" {
  if char != "b" {
    print(char)
  }
}
