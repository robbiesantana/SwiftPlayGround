//: [Previous](@previous)
/*
 Como limitar acceso a la data interna de swift con access control
 Las palabras utilizadas son
 private : Nadie fuera de la estructura puede usar esto
 fileprivate : Nadie fuera del archivo utiliza esto
 public: Pa todo el mundo y compartir
 */

import Foundation

struct BankAccount {
    private var funds = 0
    
    mutating func deposit(amount: Int) {
        funds += amount
    }
    
    mutating func withdraw(amount: Int) -> Bool {
        if funds > amount {
            funds -= amount
            return true
        } else {
            return false
        }
    }
}

var cuenta = BankAccount()

cuenta.deposit(amount: 129)
print(cuenta)

print(cuenta.deposit(amount: 333))
print(cuenta)

struct CheeseShop {
    var chese = 0
    
    var doubleCheese: Int {
        
        get {
            return chese * 2
        }
        
        set {
            chese = newValue
        }
    }
}

var apples: Int = 5
var oranges: Int = 10


let quotation = """
        Even though there's whitespace to the left,
        the actual lines aren't indented.
            Except for this line.
        Double quotes (") can appear without being escaped.

        I still have \(apples + oranges) pieces of fruit.
                        And you can't buy it
        """
print(quotation)
