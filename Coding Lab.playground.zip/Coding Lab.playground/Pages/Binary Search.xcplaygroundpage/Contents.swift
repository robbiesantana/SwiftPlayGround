// Robert Santana, 11/2024

import Foundation

let array: [Int] = [65, 75, 85, 95, 105, 115, 125, 135, 145, 155, 165, 175, 185, 195, 205, 215, 225, 235, 245, 255]

func binarySearch(_ array: [Int], _ value: Int) -> Int?  {
    //Si el valor esta vacio no imprimir nada
    guard !array.isEmpty else {
        return nil
    }
     
    if array.count == 1 {
        return array.first == value ? 0 : nil
    }
    //Definir variable left & right de tipo  Int.
    var left: Int = 0
    var right: Int = array.count - 1
    
        while left <= right {
            
        let middleIndex = (left + right) / 2
        let middleValue = array[middleIndex]
            
        if middleValue > value {
            right = middleIndex - 1
        }
        else if middleValue < value {
            left = middleIndex + 1
        }
        else if middleValue == value {
            return middleIndex
        }
    }
    return nil
}

let foundIndex = binarySearch(array, 85)
print("\(foundIndex?.description ?? "Not found")")
