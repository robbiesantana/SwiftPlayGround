// Robert Santana 12/24 ©

import Foundation

let array = [2, 4, 5, 6, 7, 8, 8, 10, 12, 14]

func binarySearch(_ array:[Int], _ value: Int) -> Int? {
    var left = 0
    if array.isEmpty!{
        return nil
    }
    right =
    return nil
}
]
