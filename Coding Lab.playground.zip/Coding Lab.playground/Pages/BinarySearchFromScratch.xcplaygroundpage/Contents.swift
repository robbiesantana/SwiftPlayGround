import Foundation

var array: [Int] = [65, 75, 85, 95, 105, 115, 125, 135, 145, 155, 165, 175, 185, 195, 205, 215, 225, 235, 245, 255]
let targeto = array.randomElement() ?? 0
for num in 256...286 {
    array.append(num)
}

func binarySearch(_ array: [Int], _ value: Int) -> Int? {
    guard !array.isEmpty else {
        return nil
    }
    if array.count == 1 {
        return array.first == value ? 0 : nil
    }
    
    var left: Int = 0
    var right: Int = array.count - 1
    
    while left <= right {
        let middleIndex = (left + right) / 2
        let middleValue = array[middleIndex]
        
        if middleValue > value {
            right = middleIndex - 1
        }
        else if middleValue < value {
            left = middleIndex + 1
        }
        else if middleValue == value {
            return middleIndex
        }
    }
    return nil
}

print("Estamos trabajando con una cadena de \(array.count) valores \n \n Buscando el numero: \(targeto) 💾")
let foundIndex = binarySearch(array, targeto)

print("\n¡Oh Mira! Valor encontrado en la posicion # \(foundIndex?.description ?? "Not found") 📇")
