//: [Previous](@previous)

import Foundation

class DriverLicense {
  var name = ""
  var address = ""
  var zip = 0
  var birthDate = [0, 0, 0]
  var issueDate = [0, 0, 0]
  var isOrganDonor = false
    init(name: String = "", address: String = "", zip: Int = 0, birthDate: [Int] = [0, 0, 0], issueDate: [Int] = [0, 0, 0], isOrganDonor: Bool = false) {
        self.name = name
        self.address = address
        self.zip = zip
        self.birthDate = birthDate
        self.issueDate = issueDate
        self.isOrganDonor = isOrganDonor
    }
    func imprimir() -> String {
      let nombre = self.name
        print(nombre)
        return nombre
    }
}

var account4150 = DriverLicense(name: "McLovin", address: "982 Momona St, Honolulu, HI", zip: 96820, birthDate: [6, 3, 1981], issueDate: [6, 19, 1998])

print(account4150.zip)
account4150.imprimir()
