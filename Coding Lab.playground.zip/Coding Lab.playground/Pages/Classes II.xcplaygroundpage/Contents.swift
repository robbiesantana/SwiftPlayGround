import Foundation

// Write your code below 🤾‍♂️

class Pokemon {
  var num: Int = 0
  var name: String = ""
  var type: [String]
  var ability: [String]
  
init (num: Int, name: String, type: [String], ability: [String]) {
  self.num = num
  self.name = name
  self.type = type
  self.ability = ability
}
        func displayInfo() {
       
        print("Nombre: \(self.name)")
            print("Tipo: \(self.type[0])")
        print("Habilidad: \(self.ability[0])\n")
          
  }
}
var bulbasaur: Pokemon = Pokemon(num: 1, name: "Bulbasaur", type: ["Grass 🌱", "Poison 💀"], ability: ["Overgrow"])

var charmander: Pokemon = Pokemon(num: 1, name: "Charmander", type: ["Fire 🔥"], ability: ["Blaze"])

var squirtle: Pokemon = Pokemon(num: 7, name: "Squirtle", type: ["Water 💧"], ability: ["Torrent"])

var pikachu: Pokemon = Pokemon(num: 1, name: "Pikachuuu", type: ["Digimon 🪼"], ability: ["Fire", "Water"])


// printing using methods
print("\tDigi Wikix\n")
bulbasaur.displayInfo()
pikachu.displayInfo()
charmander.displayInfo()
squirtle.displayInfo()


// Clases game

class Game {
  var name = ""
  var platform = ""
  var year = 0
  var price = 0.0
    init(name: String = "", platform: String = "", year: Int = 0, price: Double = 0.0) {
        self.name = name
        self.platform = platform
        self.year = year
        self.price = price
    }
}

var animalCrossing = Game(name: "Animal Crossing: New Horizons", platform: "Nintendo Switch", year: 2020, price: 59.99)
print(animalCrossing.name, animalCrossing.platform, animalCrossing.year, animalCrossing.price)


// Create a struct to store weather info

struct WeatherInfo {
    var city: Int
    
}
