// Robert Santana 11/24
// Closures are self-contained blocks

import SwiftUI

struct Student {
    let name: String
    var testScore: Int
    init(name: String, testScore: Int) {
        self.name = name
        self.testScore = testScore
    }
}

let students: [Student] = [
    Student(name: "Betty", testScore: 90),
    Student(name: "Luigi", testScore: 80),
    Student(name: "Jim", testScore: 70),
    Student(name: "Yillo", testScore: 60),
    Student(name: "Bohn", testScore: 77),
    Student(name: "Rane", testScore: 82),
    Student(name: "Lim", testScore: 72),
    Student(name: "Bill", testScore: 60),
    Student(name: "Flor de Oro ", testScore: 88),
    Student(name: "Jogill", testScore: 60)]
// El closure para filtrar estudiantes
var topStudentsFilter: (Student) -> Bool = { student in
    return student.testScore >= 80
}

var resultado = topStudentsFilter(Student(name: "Betty", testScore: 90))
//
//func topStudentsFilter(student: Student) -> Bool {
//    return student.testScore >= 80
//}

// let topStudents = students.filter(topStudentsFilter)
let cuadroDeHonor : [Student] = students.filter(topStudentsFilter)

//let topStudents = students.filter{ $0.testScore > 80 }


print("Cuadro de honor")
for student in cuadroDeHonor {
  print(student)
}

