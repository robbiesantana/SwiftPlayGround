import Foundation

struct Organization {
    let name: String
    var budget: Int
}

let organization = [
    Organization(name: "Ministerio de Hacienda", budget: 200),
    Organization(name: "Ministerio de Turismo", budget: 299),
    Organization(name: "Ministerio de Salud", budget: 322),
    Organization(name: "Ministerio de Educacion", budget: 522)
]

var mayorGasto: (Organization) -> Bool = { organization in
    return organization.budget > 300
}

let topMayorGasto = organization.filter(mayorGasto)

// another version filter
//Can use
//let topMaiores = organization.filter { $0.budget}

for topMaiorGasto in topMayorGasto {
    print(topMaiorGasto.name)
}


// Notes from PH video on YT.

struct Libros {
    let titulo: String,
autor: String,
anno: Int,
//editorial: String,
precio: Double
}


let libros = [
    Libros(titulo: "Cien años de soledad", autor: "Gabriel García Márquez", anno: 1967, precio: 12.50),
    Libros(titulo: "1984", autor: "George Orwell", anno: 1949, precio: 14.00),
    Libros(titulo: "Matar a un ruiseñor", autor: "Harper Lee", anno: 1960, precio: 11.00),
    Libros(titulo: "Crimen y castigo", autor: "Fiódor Dostoyevski", anno: 1866, precio: 13.50),
    Libros(titulo: "Orgullo y prejuicio", autor: "Jane Austen", anno: 1813, precio: 10.00),
    Libros(titulo: "Rayuela", autor: "Julio Cortázar", anno: 1963, precio: 12.00),
    Libros(titulo: "La sombra del viento", autor: "Carlos Ruiz Zafón", anno: 2001, precio: 15.00),
    Libros(titulo: "Los miserables", autor: "Victor Hugo", anno: 1862, precio: 17.00),
    Libros(titulo: "El proceso", autor: "Franz Kafka", anno: 1925, precio: 9.50),
    Libros(titulo: "Don Quijote de la Mancha", autor: "Miguel de Cervantes", anno: 1605, precio: 18.00),
    Libros(titulo: "El gran Gatsby", autor: "F. Scott Fitzgerald", anno: 1925, precio: 10.50),
    Libros(titulo: "El retrato de Dorian Gray", autor: "Oscar Wilde", anno: 1890, precio: 9.00),
    Libros(titulo: "El amor en los tiempos del cólera", autor: "Gabriel García Márquez", anno: 1985, precio: 13.00),
    Libros(titulo: "En busca del tiempo perdido", autor: "Marcel Proust", anno: 1913, precio: 20.00),
    Libros(titulo: "Ulises", autor: "James Joyce", anno: 1922, precio: 16.50),
    Libros(titulo: "Fahrenheit 451", autor: "Ray Bradbury", anno: 1953, precio: 12.00),
    Libros(titulo: "La metamorfosis", autor: "Franz Kafka", anno: 1915, precio: 8.00),
    Libros(titulo: "Cumbres borrascosas", autor: "Emily Brontë", anno: 1847, precio: 11.00),
    Libros(titulo: "Anna Karénina", autor: "León Tolstói", anno: 1877, precio: 14.50),
    Libros(titulo: "Hamlet", autor: "William Shakespeare", anno: 1603, precio: 9.00)
]

var annoPublicacion: (Libros) -> Bool = { libros in
    return libros.anno > 1100
}

var librosPublicadosEnAnno: [Libros] = libros.filter(annoPublicacion)

for librosPublicadosEnAnno in librosPublicadosEnAnno {
    print(librosPublicadosEnAnno.autor)
}
