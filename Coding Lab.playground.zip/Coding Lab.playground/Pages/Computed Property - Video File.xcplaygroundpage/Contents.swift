import Foundation

struct ArchivoVideo {
    va
}
