import Foundation

struct Carro {
    var millas: Double
    
    var kilometros: Double {
        get {
            return millas * 1.60934
        }
        set (nuevosKilometros) {
            millas = nuevosKilometros / 1.60934
        }
    }
}

var miCarro = Carro(millas: 299)
print(miCarro.millas)
print(miCarro.kilometros)
miCarro.kilometros = 486
print(miCarro.millas)
