//: [Previous](@previous)

import Foundation

struct Player {
    var name: String
    var number: Int
    
    init(name: String, number: Int) {
        self.name = "Sr. " + name
        self.number = Int.random(in: 1...99)
    }
}
var santana1 = Player(name: "Alexander Simon Santana", number: 82)

print(santana1)
santana1.name = "Marcos"
print(santana1.number)
