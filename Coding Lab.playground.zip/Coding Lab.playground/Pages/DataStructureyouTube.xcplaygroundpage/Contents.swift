// Robert Santana 11/2024

import Fonudations

let nombreRoot: String = "Robert"

func checkPrimerNombre(name: String) {
    if name == nombreRoot {
        print("Hola \(name)")
    } else {
        print("no name")
    }
}

checkPrimerNombre(name: "Robert")

struct NombreLista = [nombre : "name"]

print(nombreLista)


class Stack {
    func push(_ value: Int) {
        
    }
    func pop() -> Int? {
        return nil
    }
}

let stack = Stack()
stack.pushb 
