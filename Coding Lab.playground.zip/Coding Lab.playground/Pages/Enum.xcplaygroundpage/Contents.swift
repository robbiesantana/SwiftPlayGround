    import Foundation

    struct UsuariosDatos {
        var nombre: String
        var apellido: String
        var edad: Int
    }

    var usuario001: UsuariosDatos = UsuariosDatos(nombre: "Juan", apellido: "Perez", edad: 25)
    var usuario002: UsuariosDatos = UsuariosDatos(nombre: "Maria", apellido: "Perez", edad: 25)
    usuario001.nombre = "Pedro"

    // a computable variable

//    enum DiasSemanasOptions {
//        case lunes, martes, miercoles, jueves, viernes, sabado, domingo
//    }

    enum EstadoTarea: String, CaseIterable {
        case pendiente, iniciada, completada
    }

    enum DiasSemana: String, CaseIterable {
        case lunes, martes, miercoles, jueves, viernes, sabado, domingo
    }

    let enCurso = EstadoTarea.pendiente.rawValue.capitalized + " el " + DiasSemana.lunes.rawValue.capitalized

    print("Hola \(usuario001.nombre), Estado de tu tarea:", enCurso)


    // With Enumerations we know the values we will have Restaurant categories can be enums
    // While structs can be used to create an store values we don't know what name will be

    // Enums son almacenados en memoria igual que structs pero estos no pueden ser mutados
