// Robert Santana 12/2024
// Banquita© Es un Software de generacion de riqueza para los usuarios

import Foundation

enum TipoApuesta: String {
    case quniela:
    return "Juego de un número en la loteria diaria"
    case pale:
    return "Juego de dos números en la loteria diaria"
    case tripleta:
    return "Juego de tres números en la loteria diaria"
}
