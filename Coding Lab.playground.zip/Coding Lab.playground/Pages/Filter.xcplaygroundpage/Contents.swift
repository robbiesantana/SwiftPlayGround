//: [Previous](@previous)
// Robert Santana 11/24
//: [Next](@next)
import Foundation

var greeting = "Practicas de Swift by Robbie"

struct Alumno {
    let nombre: String
    let carrera: String
    let esMeritorio: Bool
    func mostrarDatos() -> String {
        return nombre + carrera
    }
}
var alumnos: [Alumno] = [
    Alumno(nombre: "Robbie", carrera: "Ingenieria", esMeritorio: true),
    Alumno(nombre: "Juan", carrera: "Ingenieria", esMeritorio: false),
    Alumno(nombre: "Pedro", carrera: "Ingenieria", esMeritorio: false),
    Alumno(nombre: "Maria", carrera: "Ingenieria", esMeritorio: false),
    Alumno(nombre: "Luis", carrera: "Ingenieria", esMeritorio: false),
    Alumno(nombre: "Sofia", carrera: "Ingenieria", esMeritorio: true),
    Alumno(nombre: "Akira", carrera: "Diseño Gráfico", esMeritorio: true),
    Alumno(nombre: "Hiroshi", carrera: "Ingenieria", esMeritorio: false),
    Alumno(nombre: "Mei", carrera: "Medicina", esMeritorio: true),
    Alumno(nombre: "Yuki", carrera: "Derecho", esMeritorio: false),
    Alumno(nombre: "Takeshi", carrera: "Ciencias de la Computación", esMeritorio: true),
    Alumno(nombre: "Sakura", carrera: "Biología", esMeritorio: true),
    Alumno(nombre: "Jiro", carrera: "Matemáticas", esMeritorio: false),
    Alumno(nombre: "Ayumi", carrera: "Arte", esMeritorio: true),
    Alumno(nombre: "Kazuki", carrera: "Economía", esMeritorio: false)
]
var allMeritorios: [Alumno] = alumnos.filter { alumno in
   return alumno.esMeritorio
}

var allMeritorios2: [Alumno] = alumnos.filter({ $0.esMeritorio })


print(alumnos)
