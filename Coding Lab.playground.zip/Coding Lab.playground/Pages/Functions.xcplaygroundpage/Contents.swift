//: [Previous](@previous)

import Foundation

func mayorQue(value: Int, numeros: [Int]) -> [Int] {
    var mayores = [Int]()
    for numero in numeros {
        if value < numero {
            mayores.append(numero)
            mayores.append(Int.random(in: 1...2229))
        }
    }
    return mayores
}
var aleatorio:Int = Int.random(in: 0...2500)
print(aleatorio)
print(mayorQue(value: 233, numeros: [123, 43, 34, 6, 47, 8, 76, 45, 345, 345, 67, 23, 523, 345, aleatorio]))
