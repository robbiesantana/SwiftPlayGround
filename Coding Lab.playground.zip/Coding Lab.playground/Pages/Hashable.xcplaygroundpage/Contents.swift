//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
/* [robbie santana]
 This is a test about hashables */

print(abs("a".hashValue % 6))
print(greeting.hashValue)

2.hashValue
