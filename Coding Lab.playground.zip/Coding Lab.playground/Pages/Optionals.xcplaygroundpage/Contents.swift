// Robert Santana 12/24

import Foundation

struct Actor {
    let name: String
}

struct Pelicula {
    var type: String
    var actor: Actor
}

var avatar = Pelicula(type: "Fantasia, 3D", actor: Acwtor(name: "Zoe Saldana"))

print(avatar.actor.name, avatar.type)

var students = ["Reem", "Princess", "Hassan", "Adam"]

students.append(avatar.actor.name)

if let randomStudent = students.randomElement() {
    print("\(randomStudent), do you know the answer?")
}
