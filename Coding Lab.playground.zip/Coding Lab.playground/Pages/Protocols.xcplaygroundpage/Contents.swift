//: [Previous](@previous)

import Foundation

// Use Opaque return types

func getRandomNumber() -> Int {
    Int.random(in: 1...600)
}

if getRandomNumber() > 200 {
    print(getRandomNumber())
} else {
    print("menor que el target")
}

