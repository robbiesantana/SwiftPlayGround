// Replicar la logica del juego Piedra, Tijera o Papel
import Foundation

func getUserChoice(userInput: String) -> String {
  if userInput == "Piedra" || userInput == "Tijera" || userInput == "Papel" {
    return userInput
  } else {
    return "Solo puedes utilizar Piedra, Tijera o Papel, muchaho."
  }
}

// Calcular la opciones de la computadora utilizando el metodo .random() y retornando la opcion en una cadena

func getComputerChoice() -> String {
  let aleatorio = Int.random(in: 0...2)
    switch aleatorio {
      case 0:
        return "Piedra"
      case 1:
        return "Tijera"
      case 2:
        return "Papel"
      default:
        return "No hay sistema"
    }
  }

// imprimiendo

func elGanadorEs(_ userChoice: String, _ compChoice: String) -> String {

  switch userChoice {
      case "Piedra":
      if compChoice == "Papel" {
        return "Ganó el sistema"
      } else if compChoice == "Tijera" {
        return "Ganaste tú, muchacho"
        }
        default:
        return "No" 
  }
}


print(getComputerChoice())
var jugadaUno = getUserChoice(userInput: "Papel")

print(jugadaUno)
