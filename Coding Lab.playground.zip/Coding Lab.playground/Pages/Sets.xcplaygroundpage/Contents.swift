//: [Previous](@previous)

import Foundation

var greeting = "Swift by Santana"

struct socialMedia {
    let name: String
    let url: String
    let image: String
    
}

var socialMediaList: [socialMedia] = [
socialMedia(name: "Twitter", url: "https://twitter.com/santana",
image: "https://x.com/Robbieicaro/photo"), socialMedia(name: "Instagram", url: "https://instagram.com/santana", image: "instagram"),
socialMedia(name: "Facebook", url: "https://facebook.com/santana", image: "facebook")
]

socialMediaList.append(socialMedia(name: "Badu Badu", url: "http://badubadu.com", image: "https://x.com/Robbieicaro/photo"))

print(socialMediaList.count)

var picnicBasket: Set = ["Strawberries", "Bread", "Red Blanket"]

picnicBasket.insert("Carrot Cake")
picnicBasket.remove("Strawberries")
picnicBasket.remove("Red Blanket")
picnicBasket.insert("Raspberries")

print(picnicBasket)
