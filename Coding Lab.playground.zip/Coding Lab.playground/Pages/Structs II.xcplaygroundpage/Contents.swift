//: [Previous](@previous)
// How to create your own structs
// Robert Santana


import Foundation

struct Ensayo {
    let title: String
    let personajes: [String]
    let ensayoDia: Int
    
    func promtSummary(personaje: [String]) {
        let personajes = personaje.joined(separator: ", ")
        print("Hoy ensayamos \(title) con los personajes \(personajes) dia de ensayo \(ensayoDia)")
        //print("\(title) by \(artists) in \(year)")
    }
}

var laVidaEsSueno = Ensayo(title: "El amor en la vida", personajes: [], ensayoDia: 12)
laVidaEsSueno.promtSummary(personaje: ["María Callas", "Luis Miguel"])
