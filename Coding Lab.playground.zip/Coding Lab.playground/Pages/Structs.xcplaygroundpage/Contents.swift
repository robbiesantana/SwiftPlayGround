// 12/12/2024
import Foundation

// Structs are in the stack and they are value types.
// Value Types are copied and mutated.

struct Quiz {
    let title: String
    let dateCreated: String
    var isFinal: Bool?
    
    init(title: String, dateCreated: Date, isFinal: Bool) {
        self.title = "COMP 100: \(title) - Semestre 2 - 2024"
        self.dateCreated = dateCreated.formatted(.dateTime)
        self.isFinal = isFinal
    }
}

var myQuiz: Quiz = Quiz(title: "Quiz #1", dateCreated: .now, isFinal: true)

if let final = myQuiz.isFinal {
    print ("Examen final")
   
    
}else {
    print("No hay examen final")
}

print("Bienvenidos al \(myQuiz.title)")
print(myQuiz.dateCreated)


var isFinal = myQuiz.isFinal
