import Foundation

print("Creado por Robbie Santana\nEl verdadero rey del mambo cuyo emoji es 🫡")

// Qué son las tuplas? es un data type.

//Aqui defino la tupla
var dominicana = (capital: "Santo Domingo", codigo: "SDQ")

// Podemos extraer los valores de la
// Ya sea por el nombre del key:

print(dominicana.capital)

// O por el numero del valor empezando por 1
print(dominicana.0)

// Puedes reasignar los valores de una tupla definiendo los valores como aqui:

var (miciudad, micodigo) = dominicana
print(miciudad, micodigo)

// Esta es una funcion que retorna una tupla
func calcularDistancia(x: Int, y: Int) -> (Int, Int) {
    var calculo1:Int = (x * y)
    var calculo2:Int = (x + y)
    return (calculo1, calculo2)
}


var viaje1 = calcularDistancia(x: 10, y: 20)
print(viaje1.0)
print(viaje1.1)

var viaje2 = calcularDistancia(x: 100, y: 200)
print(viaje2.0)
print(viaje2.1)
