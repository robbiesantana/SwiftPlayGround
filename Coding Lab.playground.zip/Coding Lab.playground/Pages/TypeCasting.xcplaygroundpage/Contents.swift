import Foundation

// Como la herencia y el typeCasting funcionan en las clases

class Pets {
    var name: String
    var age: Int
    var type: String
    var isAdopted: Bool
    var isVaccinated: Bool
    
    init(name: String, age: Int, type: String, isAdopted: Bool, isVaccinated: Bool) {
        self.name = name
        self.age = age
        self.type = type
        self.isAdopted = isAdopted
        self.isVaccinated = isVaccinated
    }
}

class Perros: Pets {
    var isGoodBoy: Bool = true
    
}


var terry = Pets(
    name: "Terry",
    age: 2,
    type: "Terrier",
    isAdopted: true,
    isVaccinated: true
)

print("El nombre de la mascota es \(terry.name)")
