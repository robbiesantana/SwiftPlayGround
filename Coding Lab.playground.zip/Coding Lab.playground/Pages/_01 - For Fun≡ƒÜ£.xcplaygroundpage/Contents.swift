// Robert Santana 11/2024

import Foundation

// Definiendo enum de los diferentes géneros
enum genero: String {
    case accion, drama, cienciaFiccion, animacion, otros
}
struct MovieModel {
    var titulos: String
    let genero: genero
    let fecha: String

    init(titulos: String, genero: genero, fecha: String) {
        self.titulos = titulos
        self.genero = genero
        self.fecha = fecha
    }
}

var badBoys: MovieModel = MovieModel(
    titulos: "Bad Boys",
    genero: .accion,
    fecha: "202")

var badBoys2: Int

let mensage: String = "Hola Mundo"
let movies: [MovieModel] = [.init(titulos: "Bad Boys", genero: .accion, fecha: "202"), .init(titulos: "Bad Boys 2", genero: .accion, fecha: "202"), .init(titulos: "Bad Boys 3", genero: .accion, fecha: "202")]

print(mensage.uppercased())
for movie in movies {
        print("\t", movie)
}

let minutes = 3
for tickmark in 0..<minutes + 1 {
    print("\(tickmark)")
}

print(badBoys.titulos)
print(badBoys.genero)
print(badBoys.fecha)
