import Foundation

// Voy a escribir un mix-tape sobre mis canciones favoritas de los últimos cinco años.

print("Me gusta el vacilón 􀑪\n")

struct Mixtape {
    let title: String
    let artist: String
    let album: String
    var year: Int
}

var mixtape = [
    Mixtape(title: "One More Time", artist: "Daft Punk", album: "Discovery", year: 2000),
    Mixtape(title: "In the End", artist: "Linkin Park", album: "Hybrid Theory", year: 2001),
    Mixtape(title: "Hey Ya!", artist: "OutKast", album: "Speakerboxxx/The Love Below", year: 2003),
    Mixtape(title: "Seven Nation Army", artist: "The White Stripes", album: "Elephant", year: 2003),
    Mixtape(title: "Hips Don't Lie", artist: "Shakira", album: "Oral Fixation, Vol. 2", year: 2005),
    Mixtape(title: "Crazy", artist: "Gnarls Barkley", album: "St. Elsewhere", year: 2006),
    Mixtape(title: "Boulevard of Broken Dreams", artist: "Green Day", album: "American Idiot", year: 2004),
    Mixtape(title: "Clocks", artist: "Coldplay", album: "A Rush of Blood to the Head", year: 2002),
    Mixtape(title: "Mr. Brightside", artist: "The Killers", album: "Hot Fuss", year: 2003)
]

mixtape.append(Mixtape(title: "Lady (Hear Me Tonight)", artist: "Modjo", album: "Lady (Hear Me Tonight)", year: 2000))
mixtape.append(Mixtape(title: "Las Avispas", artist: "Juan-Luis Guerra", album: "Bachata en fukuoka", year: 2020))
 
for track in mixtape {
    print("/Music/" + track.title + ".mp3 􀈂")
}

print("\nNumber of tracks: \(mixtape.count)")
