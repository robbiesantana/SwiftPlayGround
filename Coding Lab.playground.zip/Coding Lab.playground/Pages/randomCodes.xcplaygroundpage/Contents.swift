// Robbie Santana 11/24

import Foundation


let average = { (numbers: [Int]) -> Double in
    let sum = numbers.reduce(0, +)
    return Double(sum) / Double(numbers.count)
}

var numbers: [Int] = []
numbers.append(133)
numbers.append(352)
numbers.append(432)

print("Promedio de acciones es de: $" + average(numbers).formatted())
print(average(numbers).rounded())

func mul(_ entero: Int, _ entero2: Int) -> Int {
    return (entero * entero2)
}

print("Hoy has ganado $" + mul(numbers[0],numbers[1]).formatted())
