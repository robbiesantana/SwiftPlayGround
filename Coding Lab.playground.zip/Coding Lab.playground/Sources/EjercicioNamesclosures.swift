import Foundation

let nombres = [
    "Alejandro", "Beatriz", "Carlos", "Diana", "Eduardo",
    "Fernanda", "Gabriel", "Helena", "Ismael", "Juana",
    "Kevin", "Laura", "Miguel", "Natalia", "Oscar",
    "Paola", "Raúl", "Sandra", "Tomás", "Valentina",
    "Ximena", "Yahir", "Zoe", "Andrés", "Bianca",
    "Cristian", "Daniela", "Esteban", "Florencia", "Gustavo",
    "Héctor", "Ivana", "Javier", "Karina", "Luis",
    "María", "Nicolás", "Olga", "Pablo", "Quintin",
    "Ricardo", "Silvia", "Tania", "Ulises", "Violeta",
]

var nombresEnOrden = nombres.sorted(by: {
    s1, s2
    in return s1 > s2
})

print(nombresEnOrden)
