// Creado por: Santana, Robert
// Fecha: 27/10/2020
import Foundation

enum Planeta: Int {
    case mercurio = 1
    case venus
    case tierra
    case marte
    case jupiter
    case saturno
    case urano
    case neptuno
}

enum PuntoCardinal: String {
    case norte, sur, este, oeste
}
let direccion: PuntoCardinal = .este

print("El usuario esta mirando hacia el \(direccion.rawValue)")

func imprimePlaneta(indice: Int) {
    if let planeta: Planeta = Planeta(rawValue: indice) {
        switch planeta {
        case .tierra: print("Planeta Tierra")
        default: print("Planeta desconocido")
        }

    } else {
        print("No existe el planeta")
    }
}

imprimePlaneta(indice: 15)
