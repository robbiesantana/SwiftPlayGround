import Foundation

let tempKelvin: Double = 0

// Save variable before
let tempCelsius: Double = tempKelvin - 273.0
// Celsius is less than Kelvin

var tempFahrenheit: Double = tempCelsius * (9.0 / 5.0) + 32.0
// Celsius is less than tempFahrenheit

tempFahrenheit = floor(88)

print("The temperature is \(tempFahrenheit) degrees in Fahrenheit.")
