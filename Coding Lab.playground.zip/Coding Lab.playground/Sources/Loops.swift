import Foundation

let nbaAllStars: [String] = ["Marcos Challz", "Maria Callas", "Isabela Rosellino"]
