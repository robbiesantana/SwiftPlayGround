//
//  YoutubeExercises.swift
//  
//
//  Created by Productor on 11/19/24.
//

import Foundation


let home = House()
let temp = temperature()
temp.fahrenheit = 100
home.thermostat.temperature = temp


