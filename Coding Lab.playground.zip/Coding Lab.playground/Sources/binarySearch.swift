import Foundation

func binarySearch(array: [Int], target: Int) -> Int {
    var left: Int = 0
    var right: Int = array.count - 1

    while left <= right {
        let mid: Int = (left + right) / 2
        if array[mid] == target {
            return mid  // Element found
        } else if array[mid] < target {
            left = mid + 1  // Search in the right half
        } else {
            right = mid - 1  // Search in the left half
        }
    }

    return -1  // Element not found
}

// Example usage
let sortedArray: [Int] = [2, 3, 4, 7, 10, 15, 20, 21, 22, 22, 23, 30, 45, 74, 88, 122, 125]
let result: Int = binarySearch(array: sortedArray, target: 125)
print("Target found at index: \(result)")
print(sortedArray.count - 1)

func linearSearch(array: [Int], target: Int) -> Int {
    for (index, value) in array.enumerated() {
        if value == target {
            return index
        }
    }
    return -1  // Element not found
}

let result2 = linearSearch(array: sortedArray, target: 22)
print("Target found at index: \(result2)")
