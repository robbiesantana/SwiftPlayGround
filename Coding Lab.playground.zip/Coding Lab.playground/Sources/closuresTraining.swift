import Foundation

// Creating a closure

let sayHola: (String, String) -> String = {
    (
        name: String,
        tel: String
    ) -> String in
    "Hi \(name) your phone number is ☎️ 809-\(tel)"
}

var saludo1: String = sayHola("Robert", "544-1311")

let team: [String] = [
    "Gustava",
    "Gloria",
    "Maria",
    "Alejandra",
    "Julia",
    "Altachi",
    "Conchita",
]

var sortedTeam: [String] = team.sorted(by: { $0 > $1 })

print(sortedTeam)
print(saludo1)
