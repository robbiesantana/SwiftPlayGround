import Foundation

struct Employee {
    let name: String
    var vacationDays: Int
    var daysWorked: Int
    var vacationDaysLeft: Int {
        return vacationDays - daysWorked
    }
}

var archer = Employee(name: "Sterling Archer", vacationDays: 30, daysWorked: 0)
archer.daysWorked = 10
print(archer.vacationDaysLeft)  // 20
let aleatorio: Int = Int.random(in: 0...6)
print(aleatorio)
