// Creado por Robert Santana

import Foundation

let diaSemana: [String] = [
    "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo",
]

// enum diaSemana: String, CaseIterable {
//     case Lunes
//     case Martes
//     case Miercoles
//     case Jueves
//     case Viernes
//     case Sabado
//     case Domingo
// }

func diaRandom() -> Int {
    return diaSemana.randomElement()!
}

func diaBueno() -> String {
    return diaSemana[0]
}

let diaSuerte: String = diaRandom()
print("¿Quieres saber que dia te toca trabajar?")

if diaSuerte == diaBueno() {
    if let userInput = readLine() {
        if userInput == diaSuerte {
            print("Adivinaste, te toca trabajar el \(diaSuerte)")
        } else {
            print("No adivinaste, te toca trabajar el \(diaSuerte)")
        }
    }

} else {
    print("Hoy es \(diaSuerte) y no tienes que trabajar")
}
