import Foundation

// Enumeracion de los dias de la semana
// Se puede definir String sin valor y Swift asigna el nombre como valor

enum DiaSemana: String, CaseIterable {
    case Lunes
    case Martes
    case Miercoles
    case Jueves
    case Viernes
    case Sabado
    case Domingo
}

let diaFeriado: DiaSemana = .Domingo

switch diaFeriado {
case .Lunes:
    print("Hoy es \(diaFeriado) y no tienes que trabajar")
case .Martes:
    print("Hoy es Martes")
case .Miercoles:
    print("Hoy es Miercoles")
case .Jueves:
    print("Hoy es Jueves")
case .Viernes:
    print("Hoy es Viernes")
case .Sabado:
    print("Hoy es Sabado")
case .Domingo:
    print("Hoy es Domingo")
}

for dia in DiaSemana.allCases[1...2] {

    print(dia.rawValue)
}
