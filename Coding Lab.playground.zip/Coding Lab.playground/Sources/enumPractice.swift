import Foundation

// Enums son como Structs pero con valores predefinidos
// Son parte de algo llamado Stack, quiere decir que son valores que se pueden cambiar

struct CarModel {
    let brand: String
    let model: String
}

var car1: CarModel = CarModel(brand: "Ford", model: "Fiesta")
var car2: CarModel = CarModel(brand: "Chevrolet", model: "Camaro")

enum CarBrandOption {
    case Ford
    case Chevrolet
    case Toyota
    case Honda
    case Nissan
}

//enumeraciones de codeacademy
