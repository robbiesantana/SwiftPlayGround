// Write your code below

enum ProductType: String, CaseIterable {
    case aceRepository = "Ace Repository"
    case dealForcer = "Deal Forcer"
    case kadencePlanner = "Kadence Planner"
    case mailCannon = "Mail Cannon"
}

enum Edition: String {
    case basic, premium, ultimate
    mutating func upgrade() {
        switch self {
        case .basic:
            self = .premium
        case .premium:
            self = .ultimate
        case .ultimate:
            print("\(self) can't upgrade further'")
        }
    }
}

func displayProductOfferings() {
    print("There are \(ProductType.allCases.count) companies and they are")
    for product in ProductType.allCases {
        print("*** \(product.rawValue)")
    }
}

enum DeliveryMethod {
    case cloudDigital(isLifeTime: Bool)
    case shipping(weight: Int)

    var shippingCost: Int {
        switch self {
        case .shipping(let weight):
            return weight * 2
        case .cloudDigital:
            return (0)
        }
    }
}

func sendOrderConfirmation(for productType: ProductType) {
    print("Order confirmation sent for \(productType.rawValue)")
}
