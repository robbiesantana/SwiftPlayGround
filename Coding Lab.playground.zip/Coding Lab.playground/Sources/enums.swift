// Robert Santana 11/2024
// enum que utiliza computed method

import Foundation

enum DiaSemana: String, CaseIterable {
    case lunes, martes, miercoles, jueves, viernes, sabado, domingo

    var diaLibre: String {
        return "\(self.rawValue.capitalized)\t Estas libre"
    }
}
var diaFeriado: [DiaSemana] = [.martes, .lunes]

print("Este es tu calendario para la proxima semana\t")

for dia: DiaSemana in DiaSemana.allCases {
    let diasLibres: Set<DiaSemana> = [.jueves, .viernes]
    if diasLibres.contains(dia) {
        print(dia.diaLibre, "\n")
    } else {
        print("Horario\t \(dia.rawValue.capitalized): 9am - 5pm\n")
    }
}
