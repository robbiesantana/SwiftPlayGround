// #include <stdio.h>

// int main()
// {
//   char nombre[50];
//   printf("Pon tu nombre amigo: ");
//   scanf("%s", nombre);

//   printf("Hola, %s! Bienvenido a tu primera app en C.\n", nombre);
//   return 0;
// }

// #include <stdio.h>

// int main()
// {
// }
