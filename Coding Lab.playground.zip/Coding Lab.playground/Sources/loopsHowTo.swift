import Foundation
import SwiftUI

let horoscopoArr: [String: String] = [
    "aries": "March 21 - April 19",
    "taurus": "April 20 - May 20",
    "gemini": "May 21 - June 20",
    "cancer": "June 21 - July 22",
    "leo": "July 23 - August 22",
    "virgo": "August 23 - September 22",
    "libra": "September 23 - October 22",
    "scorpio": "October 23 - November 21",
    "sagittarius": "November 22 - December 21",
    "capricorn": "December 22 - January 19",
    "aquarius": "January 20 - February 18",
    "pisces": "February 19 - March 20",
]

for (signo, fecha) in horoscopoArr {
    print("\(signo.uppercased()) is starting at \(fecha)")
}

let add: (Int, Int) -> Int = {
    intOne,
    intTwo in
    return intOne + intTwo
}

var miAscendente: (String) -> String = {

}
let miSigno = horoscopoArr.count
print(add(333, 212))
print(miSigno)
