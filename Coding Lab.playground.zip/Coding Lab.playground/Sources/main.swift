import Foundation

// Crear un array de 10,000 elementos inicializados en 0
var array = [Int](repeating: 0, count: 10000)

// Capturar el tiempo de inicio
let startTime = Date()

// Ejecutar 1 billón de iteraciones anidadas
for i in 0..<10000 {
    for j in 0..<100000 {
        array[i] += j
    }
}

// Capturar el tiempo de finalización
let endTime = Date()

// Calcular y mostrar el tiempo de ejecución en segundos
let executionTime = endTime.timeIntervalSince(startTime)
print("Tiempo de ejecución: \(executionTime) segundos")
