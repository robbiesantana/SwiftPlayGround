import Foundation

var band: String? = "Heroes del Silencio"
var disco: String? = Nil

if let nombreConcierto = nombre {}
