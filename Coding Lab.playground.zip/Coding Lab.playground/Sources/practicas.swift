// Pregunta por el numero de veces que se quiere saludar y saluda ese numero de veces
// Number of times to greet is asked and greets that number of times
// Created by Robbie Icarus on 2020-10-07.

import Foundation

let primer_saludo: String = "Esta es quizas la primera vez que vez este mensaje"
let saludo_posterior: String = "Hasta luego, cocodrilo"

print("Por favor introduce el numero de veces que quieres que te salude")

if let input = readLine(), let times = Int(input) {
    var numero_de_saludos: Int = 0

    while numero_de_saludos < times {
        if numero_de_saludos < 8 {
            print(primer_saludo)
        } else {
            print(saludo_posterior)
        }
        numero_de_saludos += 1
    }
}
