import Foundation

// Definir el modelo de datos
class Greeting: Codable {
    var message: String
    var occasion: Int
    
    init(message: String, occasion: Int) {
        self.message = message
        self.occasion = occasion
    }
}

// Función para guardar los saludos en UserDefaults
func saveGreetings(_ greetings: [Greeting]) {
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(greetings) {
        UserDefaults.standard.set(encoded, forKey: "greetings")
    }
}

// Función para cargar los saludos desde UserDefaults
func loadGreetings() -> [Greeting] {
    if let savedGreetings = UserDefaults.standard.object(forKey: "greetings") as? Data {
        let decoder = JSONDecoder()
        if let loadedGreetings = try? decoder.decode([Greeting].self, from: savedGreetings) {
            return loadedGreetings
        }
    }
    return []
}

// Crear saludos y almacenarlos
let first_greeting = Greeting(message: "Nice to meet you!", occasion: 0)
let later_greeting = Greeting(message: "How are you?", occasion: 1)
var greetings = [Greeting]()

var greeting_occasion: Int = 0

while greeting_occasion < 14 {
    if greeting_occasion < 1 {
        greetings.append(first_greeting)
        print(first_greeting.message)
    } else {
        greetings.append(later_greeting)
        print(later_greeting.message)
    }
    greeting_occasion += 1
}

// Guardar los saludos en UserDefaults
saveGreetings(greetings)

// Cargar los saludos desde UserDefaults y mostrarlos
let loadedGreetings = loadGreetings()
for greeting in loadedGreetings {
    print("Occasion: \(greeting.occasion), Message: \(greeting.message)")
}