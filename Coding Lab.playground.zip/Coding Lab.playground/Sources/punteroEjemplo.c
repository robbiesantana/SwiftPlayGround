
#include <stdio.h>

int main()
{
    int x = 10;  // Declaramos una variable entera
    int *p = &x; // Declaramos un puntero que apunta a x

    printf("Direccion de x: %p\n", (void *)&x); // Imprime la dirección de x
    printf("Valor de p: %p\n", (void *)p);      // Imprime la dirección almacenada en p (la dirección de x)
    printf("Valor apuntado por p: %d\n", *p);   // Imprime el valor en la dirección apuntada por p

    *p = 20;                             // Cambiamos el valor en la dirección a la que apunta p
    printf("Nuevo valor de x: %d\n", x); // Imprime el nuevo valor de x

    return 0;
}