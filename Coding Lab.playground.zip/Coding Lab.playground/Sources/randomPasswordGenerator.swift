import Foundation

var passwdRandom: [Int] = []

var passwdLetra: [String] = []

for _ in 1...20 {
    let numerito: Int = Int.random(in: 1...222)
    passwdRandom.append(numerito)
}
print(passwdRandom)
