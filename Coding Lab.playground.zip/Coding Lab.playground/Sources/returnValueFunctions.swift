import Cocoa

let root: Double = sqrt(122)

print(root)

func rollDice() -> Int {
    return Int.random(in: 1...1982)
}

let result = rollDice()

print(result)

func areLettersIdentical(string1: String, string2: String) -> Bool {
    string1.sorted() == string2.sorted()
}

var primo = areLettersIdentical(
    string1: "AAA",
    string2: "AAA")

print(primo)
