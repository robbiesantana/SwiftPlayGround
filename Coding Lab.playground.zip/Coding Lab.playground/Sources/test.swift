import Foundation

// let average: ([Double]).Type = (nums: [Double])

let average = { (nums:[Double]) }
