import Foundation

func myFirstFunction(apodo: String) {
    print("Hola \(apodo)!\nEsta es una funcion de Swift creada con el proposito de aprender.")
    mySecondFunction(tel: "802-2482")
}

func mySecondFunction(tel: String) {
    var numero: Int = 786
    print("Si eres de Miami tu tel empieza con \(numero)-\(tel).")
}

func getUserName() -> String {
    let username: String = "Alexander, Robert"
    myFirstFunction(apodo: "Jose")
    return username
}

getUserName()

