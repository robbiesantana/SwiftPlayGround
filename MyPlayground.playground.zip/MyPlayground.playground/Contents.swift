import Cocoa

print("======= Tienda Prin Duarte =======")
print("         Tel: 544-2322           ")
print("==================================")
print("            Recibo               ")

var receipt = [12.00, 3.75, 6.50, 19.99]



// Cálculo y impresión de productos
var total: Double = 0.0
for (index, item) in receipt.enumerated() {
    print("Producto \(index + 1): $\(String(format: "%.2f", item))")
    total += item
}

// Cálculo del total con impuestos
total *= 1.08875
print("==================================")
print("Total con impuestos: $\(String(format: "%.2f", total))")
print("==================================")
print("  Gracias por elegir nuestra tienda")
print("==================================")
