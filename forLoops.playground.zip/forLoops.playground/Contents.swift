import Foundation
import SwiftUI

let horoscopeArray: [String: String] = [
    "aries": "March 21 - April 19",
    "taurus": "April 20 - May 20",
    "gemini": "May 21 - June 20",
    "cancer": "June 21 - July 22",
    "leo": "July 23 - August 22",
    "virgo": "August 23 - September 22",
    "libra": "September 23 - October 22",
    "scorpio": "October 23 - November 21",
    "sagittarius": "November 22 - December 21",
    "capricorn": "December 22 - January 19",
    "aquarius": "January 20 - February 18",
    "pisces": "February 19 - March 20",
]

//for (signo, fecha) in horoscopeArray {
//    print("\(signo.uppercased()) is starting at \(fecha)")
//}

for fecha in horoscopeArray.values {
  let signo = horoscopeArray.first(where: { $0.value == fecha })?.key ?? "Unknown"
    print("\(signo.uppercased()) is starting at \(fecha)")
}
